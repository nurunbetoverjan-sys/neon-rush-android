# NEON RUSH Android project

This is an Android Studio project that packages the NEON RUSH v1.1 HTML game inside an Android WebView.
The game is stored locally in `app/src/main/assets/index.html`; it does not need internet access to play.

## Build an APK (free)

1. Install Android Studio: https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the extracted `neon_rush_android` folder.
4. Allow Android Studio to sync Gradle and install Android SDK Platform 35 if prompted.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build finishes, use the **locate** link in the notification. The APK is usually at:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Transfer that APK to your Android phone and open it to install. You may need to allow installs from your file manager/browser.

## Notes
- Package ID: `com.lorderzhan.neonrush`
- Version: 1.1
- Minimum Android version: Android 6.0 (API 23)
- This is a debug APK when built using the steps above. For Play Store publishing, create a signed release build in Android Studio.
- No ads, analytics, account system, or internet permission are included.
- If Android Studio reports a Gradle/SDK version prompt, accept its recommended compatible updates.
